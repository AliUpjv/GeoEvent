package com.example.geoevent.ui

import com.example.geoevent.domain.AuthRepository
import com.example.geoevent.data.FirebaseAuthRepository
import com.example.geoevent.MapActivity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.geoevent.R
import kotlinx.coroutines.launch

/**
 * Écran de connexion et d'inscription, point d'entrée de l'application.
 *
 * Déclarée comme Activity de lancement (LAUNCHER) dans le Manifest : c'est
 * elle qui s'ouvre en premier au démarrage de l'app.
 */
class AuthActivity : AppCompatActivity() {

    private val authRepo: AuthRepository = FirebaseAuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Si un utilisateur est déjà connecté (session Firebase persistante),
        // on évite de lui montrer à nouveau l'écran de connexion.
        if (authRepo.getCurrentUserId() != null) { goToMap(); return }

        setContentView(R.layout.activity_auth)

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val email = findViewById<EditText>(R.id.etEmail).text.toString()
            val password = findViewById<EditText>(R.id.etPassword).text.toString()
            // lifecycleScope.launch démarre une coroutine liée au cycle de vie
            // de l'Activity : elle est annulée automatiquement si l'Activity
            // est détruite avant la fin de l'appel réseau, évitant tout crash
            // lié à une mise à jour de vue sur une Activity déjà détruite.
            lifecycleScope.launch {
                try { authRepo.login(email, password); goToMap() }
                catch (e: Exception) {
                    Toast.makeText(this@AuthActivity,
                        "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

        findViewById<Button>(R.id.btnRegister).setOnClickListener {
            val email = findViewById<EditText>(R.id.etEmail).text.toString()
            val password = findViewById<EditText>(R.id.etPassword).text.toString()
            lifecycleScope.launch {
                try { authRepo.register(email, password); goToMap() }
                catch (e: Exception) {
                    Toast.makeText(this@AuthActivity,
                        "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun goToMap() {
        startActivity(Intent(this, MapActivity::class.java))
        // finish() empêche de revenir à l'écran de connexion avec le bouton
        // retour une fois que l'utilisateur est authentifié.
        finish()
    }
}
