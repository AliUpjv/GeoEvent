package com.example.geoevent.domain

/**
 * Modèle de données représentant un événement géolocalisé partagé par un utilisateur.
 *
 * Cette classe appartient à la couche domain : elle ne dépend d'aucune technologie
 * externe (ni Firebase, ni Android), ce qui permet de la réutiliser quelle que soit
 * l'implémentation choisie pour le stockage (Firestore, Supabase, etc.).
 *
 * Toutes les propriétés ont une valeur par défaut, ce qui est requis par Firestore
 * pour pouvoir désérialiser automatiquement un document en instance de cette classe.
 */
data class Event(
    // Identifiant unique généré par Firestore lors de l'ajout du document.
    val id: String = "",

    // Titre court de l'événement, saisi par l'utilisateur lors de la création.
    val title: String = "",

    // Description détaillée de l'événement.
    val description: String = "",

    // Coordonnées GPS de l'événement (latitude et longitude).
    val lat: Double = 0.0,
    val lng: Double = 0.0,

    // Image associée à l'événement, encodée en base64 et stockée directement
    // dans Firestore (alternative à Firebase Storage, qui nécessite un forfait payant).
    val imageUrl: String = "",

    // Identifiant Firebase Auth de l'utilisateur ayant créé l'événement.
    // Utilisé pour vérifier les droits de suppression (auteur ou admin uniquement).
    val userId: String = "",

    // Email de l'auteur, affiché dans les détails de l'événement.
    val userEmail: String = "",

    // Horodatage de création, utilisé pour trier ou filtrer les événements récents.
    val timestamp: Long = System.currentTimeMillis(),

    // Compteur de likes. Plus ce nombre est élevé, plus le marqueur de l'événement
    // est affiché en grand sur la carte (effet "Urban Pulse").
    val likes: Int = 0
)
