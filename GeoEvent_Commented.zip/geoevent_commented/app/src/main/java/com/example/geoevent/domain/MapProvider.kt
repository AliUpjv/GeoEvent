package com.example.geoevent.domain

import android.content.Context
import android.view.ViewGroup

/**
 * Contrat d'affichage cartographique, indépendant du service utilisé.
 *
 * Cette interface permet à l'application d'utiliser n'importe quel fournisseur
 * de carte (OpenStreetMap via osmdroid, Google Maps, ou autre) sans que le domain
 * ou l'UI n'aient connaissance de l'implémentation réelle.
 *
 * Voir OsmMapProvider pour l'implémentation actuelle basée sur osmdroid.
 */
interface MapProvider {

    // Initialise le fournisseur de carte (configuration nécessaire avant affichage).
    fun initialize(context: Context)

    // Crée et insère la vue de la carte dans le conteneur fourni par l'Activity.
    fun showMap(container: ViewGroup)

    // Centre la caméra de la carte sur une position donnée, avec un niveau de zoom.
    fun centerOn(lat: Double, lng: Double, zoom: Double)

    // Ajoute un marqueur sur la carte. Le paramètre size permet de faire varier
    // la taille visuelle du marqueur (utilisé pour l'effet "Urban Pulse" selon
    // le nombre de likes). Le type de retour est Any car chaque fournisseur de
    // carte a son propre type de marqueur natif (ex: Marker pour osmdroid).
    fun addMarker(lat: Double, lng: Double, title: String, size: Int = 1): Any

    // Supprime tous les marqueurs actuellement affichés sur la carte.
    fun removeAllMarkers()

    // Enregistre un callback appelé lorsque l'utilisateur tape sur la carte,
    // avec les coordonnées GPS réelles correspondant au point touché.
    fun setOnMapClickListener(listener: (Double, Double) -> Unit)
}
