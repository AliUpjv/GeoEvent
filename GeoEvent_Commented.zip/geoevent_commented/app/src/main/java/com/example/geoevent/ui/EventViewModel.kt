package com.example.geoevent.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.geoevent.data.FirestoreEventRepository
import com.example.geoevent.domain.Event
import com.example.geoevent.domain.EventRepository
import com.example.geoevent.domain.GetEventsUseCase
import com.example.geoevent.domain.LocationUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel central reliant la couche UI à la couche domain pour tout ce qui
 * concerne les événements.
 *
 * Un ViewModel Android survit aux changements de configuration (rotation
 * d'écran, par exemple) car il est conservé par le ViewModelStore associé au
 * cycle de vie de l'Activity hôte, indépendamment de l'instance d'Activity
 * elle-même. Les données qu'il contient ne sont donc pas perdues lors d'une
 * rotation, contrairement à des données stockées directement dans l'Activity.
 *
 * Limite connue : ce ViewModel instancie directement FirestoreEventRepository
 * plutôt que de recevoir l'interface EventRepository par injection de
 * dépendances (Hilt, par exemple). C'est une simplification assumée pour ce
 * projet, qui introduit un léger couplage qu'on améliorerait avec plus de temps.
 */
class EventViewModel : ViewModel() {

    private val repository: EventRepository = FirestoreEventRepository()
    private val locationUseCase = LocationUseCase()
    private val getEventsUseCase = GetEventsUseCase(repository, locationUseCase)

    // StateFlow : flux observable qui conserve toujours sa dernière valeur et
    // notifie automatiquement les Activities abonnées à chaque changement.
    // _events est privé et mutable (modifiable uniquement depuis ce ViewModel),
    // tandis que events est public et en lecture seule pour l'extérieur.
    private val _events = MutableStateFlow<List<Event>>(emptyList())
    val events: StateFlow<List<Event>> = _events

    private val _userRole = MutableStateFlow("user")
    val userRole: StateFlow<String> = _userRole

    /**
     * Déclenche le chargement (et l'écoute en temps réel) des événements,
     * avec un filtrage optionnel par distance si la position GPS de
     * l'utilisateur est disponible.
     */
    fun loadEvents(
        userLat: Double? = null,
        userLng: Double? = null,
        maxKm: Double = 50.0
    ) {
        getEventsUseCase.getEventsRealtime(
            onUpdate = { _events.value = it },
            userLat = userLat,
            userLng = userLng,
            maxDistanceKm = maxKm
        )
    }

    fun setUserRole(role: String) {
        _userRole.value = role
    }

    fun likeEvent(eventId: String) {
        // viewModelScope.launch lance une coroutine automatiquement annulée
        // si le ViewModel est détruit, évitant les fuites mémoire.
        viewModelScope.launch {
            repository.likeEvent(eventId)
        }
    }

    fun deleteEvent(eventId: String) {
        viewModelScope.launch {
            repository.deleteEvent(eventId)
        }
    }
}
