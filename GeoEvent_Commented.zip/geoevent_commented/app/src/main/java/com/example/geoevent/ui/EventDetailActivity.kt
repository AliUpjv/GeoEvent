package com.example.geoevent.ui

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.geoevent.R
import com.example.geoevent.data.FirebaseAuthRepository
import com.example.geoevent.data.FirestoreEventRepository
import com.example.geoevent.domain.AuthRepository
import com.example.geoevent.domain.EventRepository
import kotlinx.coroutines.launch

/**
 * Écran de détail d'un événement : affichage des informations complètes,
 * possibilité de liker, et suppression réservée à l'auteur ou à un admin.
 *
 * Toutes les données affichées sont transmises via l'Intent depuis l'écran
 * d'origine (MapActivity), évitant une nouvelle requête Firestore inutile
 * puisque les données sont déjà disponibles côté client.
 */
class EventDetailActivity : AppCompatActivity() {

    private val eventRepo: EventRepository = FirestoreEventRepository()
    private val authRepo: AuthRepository = FirebaseAuthRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_detail)

        val eventId = intent.getStringExtra("eventId") ?: return
        val title = intent.getStringExtra("title") ?: ""
        val description = intent.getStringExtra("description") ?: ""
        val imageBase64 = intent.getStringExtra("imageUrl") ?: ""
        val userEmail = intent.getStringExtra("userEmail") ?: ""
        val userRole = intent.getStringExtra("userRole") ?: "user"
        val eventUserId = intent.getStringExtra("userId") ?: ""
        val likes = intent.getIntExtra("likes", 0)

        findViewById<TextView>(R.id.tvTitle).text = title
        findViewById<TextView>(R.id.tvDescription).text = description
        findViewById<TextView>(R.id.tvAuthor).text = "Par $userEmail"
        findViewById<TextView>(R.id.tvLikes).text = "$likes ❤️"

        // Décodage de l'image base64 stockée dans Firestore vers un Bitmap
        // affichable. Le try/catch protège contre une chaîne corrompue ou
        // un format d'image inattendu.
        if (imageBase64.isNotEmpty()) {
            try {
                val bytes = Base64.decode(imageBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                findViewById<ImageView>(R.id.ivEventImage).setImageBitmap(bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Règle de sécurité côté UI : le bouton supprimer n'est visible que
        // si l'utilisateur connecté est l'auteur de l'événement, ou un admin.
        // Cette vérification reste côté client ; une sécurité complète
        // nécessiterait également des Firestore Security Rules côté serveur.
        val currentUid = authRepo.getCurrentUserId()
        val canDelete = userRole == "admin" || currentUid == eventUserId
        findViewById<Button>(R.id.btnDelete).visibility =
            if (canDelete) View.VISIBLE else View.GONE

        findViewById<Button>(R.id.btnLike).setOnClickListener {
            lifecycleScope.launch {
                try {
                    eventRepo.likeEvent(eventId)
                    // Mise à jour immédiate de l'affichage local du compteur,
                    // sans attendre que le listener temps réel de la carte
                    // ne redescende la nouvelle valeur depuis Firestore.
                    val current = findViewById<TextView>(R.id.tvLikes).text
                        .toString().replace(" ❤️", "").toIntOrNull() ?: 0
                    findViewById<TextView>(R.id.tvLikes).text = "${current + 1} ❤️"
                    Toast.makeText(this@EventDetailActivity, "Aimé !", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@EventDetailActivity, "Erreur : ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            lifecycleScope.launch {
                try {
                    eventRepo.deleteEvent(eventId)
                    Toast.makeText(this@EventDetailActivity, "Supprimé", Toast.LENGTH_SHORT).show()
                    finish()
                } catch (e: Exception) {
                    Toast.makeText(this@EventDetailActivity, "Erreur : ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
