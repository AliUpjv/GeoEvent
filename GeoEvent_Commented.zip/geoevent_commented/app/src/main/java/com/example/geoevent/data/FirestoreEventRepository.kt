package com.example.geoevent.data

import com.example.geoevent.domain.Event
import com.example.geoevent.domain.EventRepository
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.tasks.await

/**
 * Implémentation concrète d'EventRepository basée sur Firebase Firestore.
 *
 * Cette classe est la seule de tout le projet à connaître l'existence de
 * Firestore pour la gestion des événements. Si on remplaçait Firebase par
 * une autre solution backend, seule cette classe serait à réécrire.
 */
class FirestoreEventRepository : EventRepository {

    private val db = Firebase.firestore
    private val collection = db.collection("events")

    override suspend fun getEvents(): List<Event> {
        // Lecture ponctuelle : récupère tous les documents de la collection
        // une seule fois, sans s'abonner aux changements futurs.
        return collection.get().await().documents.mapNotNull {
            it.toObject(Event::class.java)?.copy(id = it.id)
        }
    }

    override fun getEventsRealtime(onUpdate: (List<Event>) -> Unit) {
        // addSnapshotListener ouvre une connexion persistante avec Firestore :
        // ce callback est rappelé automatiquement à chaque modification de la
        // collection (ajout, suppression, update), sans requête manuelle.
        // C'est ce mécanisme qui permet l'affichage en temps réel des événements
        // créés par d'autres utilisateurs.
        collection.addSnapshotListener { snapshot, _ ->
            val events = snapshot?.documents?.mapNotNull {
                it.toObject(Event::class.java)?.copy(id = it.id)
            } ?: emptyList()
            onUpdate(events)
        }
    }

    override suspend fun addEvent(event: Event): String {
        val ref = collection.add(event).await()
        return ref.id
    }

    override suspend fun deleteEvent(eventId: String) {
        collection.document(eventId).delete().await()
    }

    override suspend fun likeEvent(eventId: String) {
        // runTransaction garantit que la lecture puis l'écriture du compteur
        // de likes sont effectuées de façon atomique. Sans cela, si deux
        // utilisateurs likent au même instant, l'un des deux likes pourrait
        // être perdu (lecture de la même valeur avant que l'autre n'écrive).
        db.runTransaction { transaction ->
            val ref = collection.document(eventId)
            val current = transaction.get(ref).getLong("likes") ?: 0
            transaction.update(ref, "likes", current + 1)
        }.await()
    }
}
