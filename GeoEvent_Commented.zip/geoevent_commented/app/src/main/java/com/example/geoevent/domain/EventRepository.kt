package com.example.geoevent.domain

/**
 * Contrat d'accès aux données pour les événements géolocalisés.
 *
 * Cette interface appartient à la couche domain et ne dit jamais COMMENT les
 * opérations sont réalisées techniquement, seulement CE QU'il est possible de faire.
 * La couche data fournit une implémentation concrète (voir FirestoreEventRepository).
 *
 * Grâce à cette abstraction, remplacer Firebase par une autre solution backend
 * (Supabase, Realtime Database...) ne nécessite que la création d'une nouvelle
 * classe implémentant cette interface, sans modifier le domain ni l'UI.
 */
interface EventRepository {

    // Récupère l'ensemble des événements en une seule fois (lecture ponctuelle).
    suspend fun getEvents(): List<Event>

    // S'abonne aux événements et reçoit une mise à jour à chaque changement
    // dans la source de données (ajout, suppression, modification).
    // C'est ce mécanisme qui permet l'affichage en temps réel sur la carte.
    fun getEventsRealtime(onUpdate: (List<Event>) -> Unit)

    // Ajoute un nouvel événement et retourne l'identifiant généré.
    suspend fun addEvent(event: Event): String

    // Supprime un événement à partir de son identifiant.
    suspend fun deleteEvent(eventId: String)

    // Incrémente le compteur de likes d'un événement de façon atomique,
    // pour éviter les conflits si plusieurs utilisateurs liken en même temps.
    suspend fun likeEvent(eventId: String)
}
