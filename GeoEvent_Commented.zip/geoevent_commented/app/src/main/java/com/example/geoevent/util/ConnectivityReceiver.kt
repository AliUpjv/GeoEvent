package com.example.geoevent.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager

/**
 * BroadcastReceiver Android écoutant les changements de connectivité réseau
 * du système, afin d'avertir l'utilisateur en cas de perte de connexion.
 *
 * Ce receiver doit être enregistré dans onCreate() de l'Activity qui l'utilise
 * et impérativement désinscrit dans onDestroy(), sous peine de fuite mémoire
 * (le receiver continuerait à référencer l'Activity même après sa destruction).
 */
class ConnectivityReceiver(
    private val onConnectivityChanged: (Boolean) -> Unit
) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE)
                as ConnectivityManager
        val isConnected = cm.activeNetworkInfo?.isConnected == true
        onConnectivityChanged(isConnected)
    }
}
