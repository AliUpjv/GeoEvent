package com.example.geoevent.data

import android.content.Context
import android.view.MotionEvent
import android.view.ViewGroup
import com.example.geoevent.domain.MapProvider
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay

/**
 * Implémentation concrète de MapProvider basée sur osmdroid, une bibliothèque
 * open-source affichant des tuiles OpenStreetMap.
 *
 * Ce choix a été fait plutôt que Google Maps car osmdroid est entièrement
 * gratuit et ne nécessite ni clé API ni quota d'utilisation, ce qui convient
 * mieux à un projet étudiant sans budget.
 */
class OsmMapProvider : MapProvider {

    private lateinit var mapView: MapView

    override fun initialize(context: Context) {
        // osmdroid exige un user-agent valide pour respecter la politique
        // d'utilisation des serveurs de tuiles OpenStreetMap.
        Configuration.getInstance().userAgentValue = context.packageName
    }

    override fun showMap(container: ViewGroup) {
        mapView = MapView(container.context)
        // MAPNIK est le style de tuiles par défaut d'OpenStreetMap.
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        // Active le zoom et le déplacement au doigt nativement.
        mapView.setMultiTouchControls(true)
        container.addView(mapView)
    }

    override fun centerOn(lat: Double, lng: Double, zoom: Double) {
        val point = GeoPoint(lat, lng)
        mapView.controller.setZoom(zoom)
        mapView.controller.setCenter(point)
    }

    override fun addMarker(lat: Double, lng: Double, title: String, size: Int): Any {
        val marker = Marker(mapView)
        marker.position = GeoPoint(lat, lng)
        marker.title = title
        // Ancre le marqueur par son centre horizontal et le bas de l'icône,
        // pour que la pointe du marqueur corresponde bien à la position GPS.
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        mapView.overlays.add(marker)
        mapView.invalidate() // Force le redessin de la carte.
        return marker
    }

    override fun removeAllMarkers() {
        mapView.overlays.clear()
        mapView.invalidate()
    }

    override fun setOnMapClickListener(listener: (Double, Double) -> Unit) {
        // Un Overlay osmdroid permet d'intercepter les interactions tactiles
        // sur la carte. On convertit ici la position du clic en pixels écran
        // vers de véritables coordonnées GPS grâce à mapView.projection.
        val overlay = object : Overlay() {
            override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
                val point = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt())
                listener(point.latitude, point.longitude)
                return true
            }
        }
        mapView.overlays.add(overlay)
    }

    // Méthodes additionnelles (non présentes dans l'interface MapProvider)
    // permettant à MapActivity de relayer son propre cycle de vie vers la
    // carte osmdroid, pour économiser les ressources quand l'app n'est plus
    // au premier plan.
    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
}
