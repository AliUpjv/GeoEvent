package com.example.geoevent.data

import com.example.geoevent.domain.AuthRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.tasks.await

/**
 * Implémentation concrète d'AuthRepository basée sur Firebase Auth pour
 * l'identité, combinée à Firestore pour la gestion des rôles.
 *
 * Firebase Auth gère uniquement "qui est l'utilisateur" (email, mot de passe,
 * identifiant unique). Il ne propose pas nativement de système de rôles
 * personnalisés accessible depuis le client Android — c'est pourquoi le rôle
 * est stocké séparément dans un document Firestore de la collection "users".
 */
class FirebaseAuthRepository : AuthRepository {

    private val auth = Firebase.auth
    private val db = Firebase.firestore

    override suspend fun login(email: String, password: String): String {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        // Une fois l'identité vérifiée par Firebase Auth, on va chercher
        // le rôle correspondant dans Firestore.
        return getUserRole(result.user!!.uid)
    }

    override suspend fun register(email: String, password: String): String {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val uid = result.user!!.uid
        // À l'inscription, on crée immédiatement le document utilisateur
        // correspondant dans Firestore avec le rôle "user" par défaut.
        // Le passage à "admin" se fait manuellement depuis la console Firebase.
        db.collection("users").document(uid)
            .set(mapOf("email" to email, "role" to "user")).await()
        return "user"
    }

    override suspend fun getUserRole(uid: String): String {
        val doc = db.collection("users").document(uid).get().await()
        // Valeur de repli "user" si le champ role est absent du document,
        // pour éviter un crash en cas de donnée incomplète.
        return doc.getString("role") ?: "user"
    }

    override fun logout() = auth.signOut()
    override fun getCurrentUserId() = auth.currentUser?.uid
    override fun getCurrentUserEmail() = auth.currentUser?.email
}
