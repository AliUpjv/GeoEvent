package com.example.geoevent.domain

/**
 * Contrat d'authentification et de gestion des utilisateurs.
 *
 * Comme pour EventRepository, cette interface isole le domain de la technologie
 * d'authentification choisie (ici Firebase Auth, voir FirebaseAuthRepository).
 *
 * Important : cette interface gère uniquement l'identité de l'utilisateur (login,
 * inscription, déconnexion). La notion de rôle (user/admin) est volontairement
 * exposée ici aussi, car Firebase Auth seul ne permet pas de stocker des rôles
 * personnalisés sans passer par un serveur (Custom Claims) — on stocke donc le
 * rôle séparément dans Firestore et on l'expose via getUserRole().
 */
interface AuthRepository {

    // Connecte un utilisateur existant et retourne son rôle ("user" ou "admin").
    suspend fun login(email: String, password: String): String

    // Crée un nouveau compte et retourne le rôle par défaut attribué ("user").
    suspend fun register(email: String, password: String): String

    // Récupère le rôle stocké dans Firestore pour un utilisateur donné.
    suspend fun getUserRole(uid: String): String

    // Déconnecte l'utilisateur actuellement authentifié.
    fun logout()

    // Retourne l'identifiant Firebase de l'utilisateur connecté, ou null si absent.
    fun getCurrentUserId(): String?

    // Retourne l'email de l'utilisateur connecté, ou null si absent.
    fun getCurrentUserEmail(): String?
}
