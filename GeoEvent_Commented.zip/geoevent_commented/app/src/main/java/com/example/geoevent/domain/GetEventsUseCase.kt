package com.example.geoevent.domain

/**
 * Orchestre la récupération des événements en appliquant les règles métier
 * de filtrage et de tri, sans jamais accéder directement à Firestore.
 *
 * Ce UseCase illustre la séparation des responsabilités : EventRepository
 * se contente de fournir des données brutes, tandis que cette classe applique
 * la logique propre à l'application (filtrer par distance, trier par popularité).
 */
class GetEventsUseCase(
    private val repository: EventRepository,
    private val locationUseCase: LocationUseCase
) {

    /**
     * S'abonne aux événements en temps réel, applique un filtrage optionnel
     * par distance si la position de l'utilisateur est connue, puis trie le
     * résultat par nombre de likes décroissant avant de notifier l'UI.
     */
    fun getEventsRealtime(
        onUpdate: (List<Event>) -> Unit,
        userLat: Double? = null,
        userLng: Double? = null,
        maxDistanceKm: Double = Double.MAX_VALUE
    ) {
        repository.getEventsRealtime { events ->
            val filtered = if (userLat != null && userLng != null) {
                locationUseCase.filterByDistance(events, userLat, userLng, maxDistanceKm)
            } else events
            onUpdate(filtered.sortedByDescending { it.likes })
        }
    }
}
