package com.example.geoevent

import android.Manifest
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.geoevent.data.OsmMapProvider
import com.example.geoevent.domain.MapProvider
import com.example.geoevent.ui.AddEventActivity
import com.example.geoevent.ui.EventViewModel
import com.example.geoevent.util.ConnectivityReceiver
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.launch

/**
 * Écran principal de l'application : affiche la carte, la position de
 * l'utilisateur, et les marqueurs représentant les événements à proximité.
 *
 * Cette Activity orchestre plusieurs responsabilités côte à côte :
 * - l'affichage cartographique (via MapProvider)
 * - la géolocalisation et ses permissions runtime
 * - l'observation réactive des événements (via EventViewModel)
 * - la détection de perte de connexion (via ConnectivityReceiver)
 */
class MapActivity : AppCompatActivity() {

    // Déclaré via le type de l'interface plutôt que l'implémentation
    // concrète OsmMapProvider, pour montrer explicitement que cette Activity
    // ne dépend que du contrat MapProvider, pas d'osmdroid en particulier.
    private val mapProvider: MapProvider = OsmMapProvider()

    // Délégué Android "by viewModels()" : crée (ou récupère, après une
    // rotation d'écran) l'instance du ViewModel liée au cycle de vie de
    // cette Activity.
    private val viewModel: EventViewModel by viewModels()

    private lateinit var locationManager: LocationManager
    private lateinit var connectivityReceiver: ConnectivityReceiver

    // Position par défaut (Paris) utilisée avant que le GPS ne renvoie
    // une position réelle.
    private var userLat = 48.8566
    private var userLng = 2.3522

    // API moderne de demande de permission runtime. Le callback est appelé
    // automatiquement avec le résultat (accordée ou refusée) après que
    // l'utilisateur a répondu à la boîte de dialogue système.
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startLocationUpdates() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mapProvider.initialize(this)
        mapProvider.showMap(findViewById(R.id.mapContainer))
        mapProvider.centerOn(userLat, userLng, 12.0)

        checkLocationPermission()
        setupConnectivityReceiver()

        // Observation du StateFlow exposé par le ViewModel : à chaque mise à
        // jour de la liste d'événements (ajout, suppression, like reçu en
        // temps réel depuis Firestore), on redessine tous les marqueurs.
        lifecycleScope.launch {
            viewModel.events.collect { events ->
                mapProvider.removeAllMarkers()
                events.forEach { event ->
                    // La taille du marqueur dépend du nombre de likes : c'est
                    // l'effet visuel "Urban Pulse" qui met en valeur les
                    // événements les plus populaires.
                    mapProvider.addMarker(event.lat, event.lng, event.title, event.likes + 1)
                }
            }
        }

        viewModel.loadEvents()

        // Premier moyen d'ajouter un événement : taper directement sur la
        // carte pour choisir une position précise.
        mapProvider.setOnMapClickListener { lat, lng ->
            val intent = Intent(this, AddEventActivity::class.java)
            intent.putExtra("lat", lat)
            intent.putExtra("lng", lng)
            startActivity(intent)
        }

        // Deuxième moyen : le bouton flottant utilise la position GPS
        // actuelle de l'utilisateur plutôt qu'un point choisi sur la carte.
        findViewById<FloatingActionButton>(R.id.fabAddEvent).setOnClickListener {
            val intent = Intent(this, AddEventActivity::class.java)
            intent.putExtra("lat", userLat)
            intent.putExtra("lng", userLng)
            startActivity(intent)
        }
    }

    /**
     * Enregistre le BroadcastReceiver qui affichera un bandeau d'alerte
     * dès que la connexion réseau du téléphone est perdue.
     */
    private fun setupConnectivityReceiver() {
        connectivityReceiver = ConnectivityReceiver { connected ->
            val banner = findViewById<TextView>(R.id.tvOfflineBanner)
            banner.visibility = if (connected) View.GONE else View.VISIBLE
        }
        @Suppress("DEPRECATION")
        registerReceiver(connectivityReceiver, IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION))
    }

    /**
     * Vérifie si la permission de géolocalisation précise est déjà accordée.
     * Si oui, démarre directement le suivi GPS ; sinon, déclenche la
     * demande runtime obligatoire depuis Android 6.0.
     */
    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) startLocationUpdates()
        else locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    /**
     * Démarre la réception des mises à jour de position GPS, toutes les
     * 5 secondes ou tous les 10 mètres de déplacement (selon ce qui arrive
     * en premier). Chaque nouvelle position recentre la carte et relance
     * le filtrage des événements par distance.
     */
    private fun startLocationUpdates() {
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 5000L, 10f
                ) { location ->
                    userLat = location.latitude
                    userLng = location.longitude
                    mapProvider.centerOn(userLat, userLng, 15.0)
                    viewModel.loadEvents(userLat, userLng, 50.0)
                }
            } catch (e: SecurityException) {
                // Filet de sécurité : la permission pourrait théoriquement
                // être révoquée entre la vérification ci-dessus et cet appel.
                e.printStackTrace()
            }
        }
    }

    // Relance le rendu de la carte osmdroid quand l'Activity revient au
    // premier plan, comme recommandé par la documentation d'osmdroid.
    override fun onResume() {
        super.onResume()
        (mapProvider as? OsmMapProvider)?.onResume()
    }

    // Coupe le rendu de la carte et arrête les mises à jour GPS dès que
    // l'Activity n'est plus au premier plan, pour économiser la batterie.
    override fun onPause() {
        super.onPause()
        (mapProvider as? OsmMapProvider)?.onPause()
        if (::locationManager.isInitialized) locationManager.removeUpdates {}
    }

    // Désinscrit le BroadcastReceiver pour éviter toute fuite mémoire :
    // un receiver non désinscrit continuerait à référencer cette Activity
    // même après sa destruction complète.
    override fun onDestroy() {
        super.onDestroy()
        if (::connectivityReceiver.isInitialized) unregisterReceiver(connectivityReceiver)
    }
}
