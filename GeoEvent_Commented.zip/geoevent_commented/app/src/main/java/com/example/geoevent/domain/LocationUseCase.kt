package com.example.geoevent.domain

import kotlin.math.*

/**
 * Logique métier liée au calcul de distances géographiques.
 *
 * Cette classe ne dépend d'aucune technologie externe : elle ne fait que des
 * calculs mathématiques purs, ce qui la rend facilement testable de façon isolée.
 */
class LocationUseCase {

    /**
     * Calcule la distance en kilomètres entre deux points GPS à l'aide de la
     * formule de Haversine, qui tient compte de la courbure de la Terre
     * (contrairement à une simple distance euclidienne entre deux coordonnées).
     */
    fun distanceKm(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val R = 6371.0 // Rayon moyen de la Terre en kilomètres.
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLng / 2).pow(2)
        return R * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    /**
     * Filtre une liste d'événements pour ne conserver que ceux situés à moins
     * de maxKm kilomètres de la position de l'utilisateur.
     */
    fun filterByDistance(
        events: List<Event>,
        userLat: Double,
        userLng: Double,
        maxKm: Double
    ): List<Event> {
        return events.filter {
            distanceKm(userLat, userLng, it.lat, it.lng) <= maxKm
        }
    }
}
